/*var mitu = 150,
	nitu = 120,
	Nitu = 100,
	mitu = 50,
	headerArea = 65;


alert( nitu );
document.write(nitu); 
var nitu = 20,
	intro = document.getElementById('intro');

intro.style.color='green';

intro.innerHTML = 'We Are Learning JavaScript.';*/



function box() {
	alert('Balloons uira gese!');
}




















